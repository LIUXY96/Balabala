Thanks for your help!

I find that madx and pyorbit give differrent results, although dx, ds, dpsi, dtheta, dphi and field error are same. 

For example, I set that dipole dx error is 0.127mm, initial coordinate: x=0.001, y=0.001. Final coordinate from madx: (0.0004504628565, -0.0004948271389, 0.001, 0, -0.0008661142371, 0), final coordinate from pyorbit: (0.00050427978, -0.00050443287, 0.001, 0, -0.00077072941, 0). Y coordinate is same but x and z direction are quit different.

Ds displacement error has same problem.

I set that dipole xsrot error is -0.126mrad, initial coordinate: x=0.001, y=0.001. Final coordinate from madx: (0.0004370733215, -0.0006298123105, 0.001, 0, -0.0008661599623, 0), final coordinate from pyorbit: (0.00044315998, -0.00056678022, 0.001, 0, -0.00086599932, -9.9609841e-10). px coordinate is quit different, and dE changes from 0 to -9.9609841e-10, which I think can not happen in real accelerator.

xyroterror and ysroterror have same problem with xsroterror. By the way, quadrupole xsroterror and ysroterror alse have this problem.

Also, I get different results form same dipole field error (I set fracerr parameter in pyorbit).

Codes ares in this two folders, you can check if I set something wrong.

Looking forward to your reply!
