import math
import os
import numpy as np

from orbit.teapot import teapot
from orbit.teapot import TEAPOT_Lattice
from bunch import Bunch
from orbit.errors import AddErrorNode
from orbit.errors import AddErrorSet

#=====Make a Teapot style lattice======

teapot_latt = teapot.TEAPOT_Ring()
print "Read MAD."
teapot_latt.readMAD("Lattice/ring.seq","mainline")
print "Lattice=",teapot_latt.getName()," length [m] =",teapot_latt.getLength()," nodes=",len(teapot_latt.getNodes())


kin_energy = 0.007  #Gev

b = Bunch()
b.mass(0.93827231)
b.getSyncParticle().kinEnergy(kin_energy)

b.addParticle(0.001, 0.0, 0.001, 0.0, 0.0, 0.0)

lostbunch = Bunch()
paramsDict = {}
paramsDict["lostbunch"] = lostbunch
paramsDict["bunch"] = b
lostbunch.addPartAttr("LostParticleAttributes") 

#========Add Errors====================

SB1XDispError = {}
SB1XDispError["sample"] = "User"
SB1XDispError["errtype"] = "BendDisplacementError"
SB1XDispError["subtype"] = "XDisp"
SB1XDispError["disp"] =   0.127/1000

SB1YDispError = {}
SB1YDispError["sample"] = "User"
SB1YDispError["errtype"] = "BendDisplacementError"
SB1YDispError["subtype"] = "YDisp"
SB1YDispError["disp"] =   0.203/1000

SB1LDispError = {}
SB1LDispError["sample"] = "User"
SB1LDispError["errtype"] = "BendDisplacementError"
SB1LDispError["subtype"] = "LongDisp"
SB1LDispError["disp"] =   0.196/1000

SB1XYRotError = {}
SB1XYRotError["sample"] = "User"
SB1XYRotError["elementtype"] = "sbend"
SB1XYRotError["errtype"] = "RotationError"
SB1XYRotError["subtype"] = "XY"
SB1XYRotError["angle"] =   0.101/1000

SB1XSRotError = {}
SB1XSRotError["sample"] = "User"
SB1XSRotError["elementtype"] = "sbend"
SB1XSRotError["errtype"] = "RotationError"
SB1XSRotError["subtype"] = "XS"
SB1XSRotError["angle"] =  -0.126/1000

SB1YSRotError = {}
SB1YSRotError["sample"] = "User"
SB1YSRotError["elementtype"] = "sbend"
SB1YSRotError["errtype"] = "RotationError"
SB1YSRotError["subtype"] = "YS"
SB1YSRotError["angle"] =   0.162/1000

print "New Lattice=",teapot_latt.getName()," length [m] =",teapot_latt.getLength()," nodes=",len(teapot_latt.getNodes())

#AddErrorNode(teapot_latt, 0.1, 1.7, SB1XDispError)
#AddErrorNode(teapot_latt, 0.1, 1.7, SB1YDispError)
#AddErrorNode(teapot_latt, 0.1, 1.7, SB1LDispError)
#AddErrorNode(teapot_latt, 0.1, 1.7, SB1XYRotError)
AddErrorNode(teapot_latt, 0.1, 1.7, SB1XSRotError)
#AddErrorNode(teapot_latt, 0.1, 1.7, SB1YSRotError)

def setFieldError(node, paramsDict):
	node.setParam("poles", paramsDict["poles"])
	node.setParam("skews", paramsDict["skews"])
	node.setParam("kls",   paramsDict["kls"])
		
for node in teapot_latt.getNodes():
	if node.getName() == "SB":
		SBnode = node
	if node.getName() == "QF":
		QFnode = node

SB1FieldError = {}
SB1FieldError["poles"] = [0, 1, 2, 3, 4]
SB1FieldError["skews"] = [0, 0, 0, 0, 0]
SB1FieldError["kls"] = [0, 0, 0, 0, 0]
SB1FieldError["errtype"] = "FieldError"
SB1FieldError["subtype"] = "BendField"
SB1FieldError["fracerr"] = 3.76E-04
SB1FieldError["sample"] = "User"


#AddErrorNode(teapot_latt, 0.1, 1.7, SB1FieldError)
#setFieldError(SBnode, SB1FieldError)


b.dumpBunch("init.dat")
teapot_latt.trackBunch(b, paramsDict)
b.dumpBunch("final.dat")
		
'''
QF1TransError = {}
QF1TransError["sample"] = "User"
QF1TransError["errtype"] = "StraightError"
QF1TransError["subtype"] = "TransDisp"
QF1TransError["dx"] =   0.130/1000*(-1)#(-1)?
QF1TransError["dy"] =  -0.036/1000*(-1)#(-1)?

QF1LongiError = {}
QF1LongiError["sample"] = "User"
QF1LongiError["errtype"] = "StraightError"
QF1LongiError["subtype"] = "LongDisp"
QF1LongiError["ds"] =  -0.289/1000*100

QF1XYRotError = {}
QF1XYRotError["sample"] = "User"
QF1XYRotError["errtype"] = "StraightError"
QF1XYRotError["subtype"] = "XYRot"
QF1XYRotError["angle"] =  -0.061/1000*100

QF1XSRotError = {}
QF1XSRotError["sample"] = "User"
QF1XSRotError["errtype"] = "StraightError"
QF1XSRotError["subtype"] = "XSRot"
QF1XSRotError["angle"] =  -0.033/1000*100*(-1)#(-1)?

QF1YSRotError = {}
QF1YSRotError["sample"] = "User"
QF1YSRotError["errtype"] = "StraightError"
QF1YSRotError["subtype"] = "YSRot"
QF1YSRotError["angle"] =   0.225/1000*100

QF1FieldError = {}
#QF1FieldError["poles"] = [2, 3, 4, 5, 6, 7, 2, 3, 4, 5, 6, 7]
#QF1FieldError["skews"] = [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1]
#QF1FieldError["kls"] = [-0.001261819574, 0.03628791308, 0.2320873024, -1131.221488, -10008.32776, -65459.31021, -0.001047858723, 0.0180353101, -0.607495449, 456.4232785, 72205.62687, -4974907.576]
QF1FieldError["poles"] = [1, 1]
QF1FieldError["skews"] = [0, 1]
QF1FieldError["kls"] = [0.0, 0.2]
QF1FieldError["errtype"] = "FieldError"
QF1FieldError["subtype"] = "QuadField"
QF1FieldError["fracerr"] = 0.5
QF1FieldError["sample"] = "User"

#AddErrorNode(teapot_latt, 0.1, 0.3, QF1TransError)
#AddErrorNode(teapot_latt, 0.1, 0.3, QF1LongiError)
#AddErrorNode(teapot_latt, 0.1, 0.3, QF1XYRotError)
#AddErrorNode(teapot_latt, 0.1, 0.3, QF1XSRotError)
#AddErrorNode(teapot_latt, 0.1, 0.3, QF1YSRotError)

AddErrorNode(teapot_latt, 0.1, 0.3, QF1FieldError)
setFieldError(QFnode, QF1FieldError)
print QFnode.getParamsDict()

'''
